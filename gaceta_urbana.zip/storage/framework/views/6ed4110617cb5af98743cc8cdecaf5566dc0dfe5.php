<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="https://www.quokasoft.com" />
    <title>Gaceta Urbana</title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('blog/assets/favicon.png')); ?>" />
    <!-- Font Awesome icons (free version)-->
    <script src="https://use.fontawesome.com/releases/v5.15.3/js/all.js" crossorigin="anonymous"></script>
    <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet"
        type="text/css" />
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800"
        rel="stylesheet" type="text/css" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link href="<?php echo e(asset('blog/css/styles.css')); ?>" rel="stylesheet" />
</head>

<body>
    <!-- Navigation-->
    <nav class="navbar navbar-expand-lg navbar-light" id="mainNav">
        <div class="container px-4 px-lg-5">
            <a class="navbar-brand" href="<?php echo e(route('blog')); ?>">Gaceta Urbana</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive"
                aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                Menu
                <i class="fas fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ms-auto py-4 py-lg-0">
                    <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="<?php echo e(route('blog')); ?>">Articulos</a></li>
                    <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="<?php echo e(route('about')); ?>">Acerca de</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Page Header-->
    <header class="masthead" style="background-image: url('<?php echo e(asset('blog/assets/img/home-bg.jpg')); ?>')">
        <div class="container position-relative px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-md-10 col-lg-8 col-xl-7">
                    <div class="site-heading">
                        <h1>Gaceta Urbana</h1>
                        <span class="subheading">Comprometidos con la información veráz.</span>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Main Content-->
    <div class="container px-4 px-lg-5">
        <div class="row gx-4 gx-lg-5 justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7">
                <?php $__currentLoopData = $covers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cover): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Post preview-->
                    <div class="post-preview">
                        <a href="<?php echo e(route('posts', $cover->id)); ?>">
                            <h2 class="post-title"><?php echo e($cover->title); ?></h2>
                            <img class="img-thumbnail mt-4" src="<?php echo e(asset('/storage/' . $cover->image_url)); ?>"
                                alt="post_image">
                            <h3 class="post-subtitle">
                                <?php echo e($cover->content); ?>

                            </h3>
                        </a>
                        <p class="post-meta">
                            Publicado por
                            <a><?php echo e($cover->author); ?></a>
                            

                            <?php
                            $date = new DateTime($cover->updated_at);
                            // echo $date->format('Y-m-d H:i');

                            $dia = $date->format('d');
                            $m = $date->format('m');
                            $mes = 'enero';
                            switch ($m) {
                            case '1':
                            $mes = 'enero';
                            break;
                            case '2':
                            $mes = 'febrero';
                            break;
                            case '3':
                            $mes = 'marzo';
                            break;
                            case '4':
                            $mes = 'abril';
                            break;
                            case '5':
                            $mes = 'mayo';
                            break;
                            case '6':
                            $mes = 'junio';
                            break;
                            case '7':
                            $mes = 'julio';
                            break;
                            case '8':
                            $mes = 'agosto';
                            break;
                            case '9':
                            $mes = 'septiembre';
                            break;
                            case '10':
                            $mes = 'octubre';
                            break;
                            case '11':
                            $mes = 'noviembre';
                            break;
                            case '12':
                            $mes = 'diciembre';
                            break;

                            default:
                            break;
                            }
                            $anio = $date->format('Y');

                            echo ' (' . $dia . ' de ' . $mes . ' de ' . $anio . ').';
                            ?>
                        </p>
                    </div>
                    <!-- Divider-->
                    <hr class="my-4" />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if(!$fin): ?>
                    <!-- Pager-->
                    <div class="d-flex justify-content-end mb-4">
                        <form action="<?php echo e(route('blog')); ?>" method="GET">
                            <?php echo e(csrf_field()); ?>

                            <input name="pagination" value="<?php echo e($pagination + 5); ?>" hidden>
                            <button type="submit" class="btn btn-primary text-uppercase">
                                Articulos antiguos →</button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Footer-->
    <footer class="border-top">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-md-10 col-lg-8 col-xl-7">
                    <ul class="list-inline text-center">
                        
                        <li class="list-inline-item">
                            <a target="_blank" href="https://www.facebook.com/Gaceta-Urbana-101525095546658">
                                <span class="fa-stack fa-lg">
                                    <i class="fas fa-circle fa-stack-2x"></i>
                                    <i class="fab fa-facebook-f fa-stack-1x fa-inverse"></i>
                                </span>
                            </a>
                        </li>
                        
                    </ul>
                    <div class="small text-center text-muted fst-italic">Copyright &copy; Gaceta Urbana 2021</div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="<?php echo e(asset('blog/js/scripts.js')); ?>"></script>
</body>

</html>
<?php /**PATH E:\htdocs\gaceta_urbana\resources\views/blog.blade.php ENDPATH**/ ?>