

<?php $__env->startSection('content'); ?>

    <div class="card card-secondary">
        <div class="card-header">
            <h3 class="card-title">Publicacion </h3>
            <h4 class="card-title">Articulo: <?php echo e($cover->title); ?></h4>
        </div>
        <!-- /.card-header -->
        <!-- form start -->
        <div class="card-body">

            <div class="card mb-4">
                <div class="card-header"><i class="fas fa-table mr-1"></i>Publicacion</div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>Titulo</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($post->title); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('admin.post.destroy', $post->id)); ?>"
                                                method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <a class="btn btn-primary"
                                                    href="<?php echo e(route('admin.post.edit', $post->id)); ?>">Editar</a>
                                                <button type="submit" class="btn btn-danger">Eliminar</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
        <!-- /.card-body -->
        <div class="card-footer">
            <a class="btn btn-warning" href="<?php echo e(route('admin.post.create',$cover->id)); ?>">Agregar</a>
            <a class="btn btn-primary" href="<?php echo e(route('admin.cover.index')); ?>">Atras</a>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\htdocs\gaceta_urbana\resources\views/admin/post/index.blade.php ENDPATH**/ ?>