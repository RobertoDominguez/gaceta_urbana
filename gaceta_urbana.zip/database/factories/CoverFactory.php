<?php

namespace Database\Factories;

use App\Models\Cover;
use Illuminate\Database\Eloquent\Factories\Factory;

class CoverFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Cover::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
